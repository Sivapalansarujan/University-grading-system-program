
progress = 0
trailer  = 0
# I declare that my work contains no examples of misconduct, such as plagiarism, or collusion

# Any code taken from other sources is referenced within my code solution.

# Student ID: w1990914

# Date: 19.04.2023


#Initializing Varibales
retriever= 0
exclude  = 0
total=0
student_dic = {}
Input_result = ''

# Loop to input a correct data
def progression_results(word):
    word_for_describe = word
    while True:
        try:
            word = int(input("Enter your credits at " + word_for_describe + ": "))
            if word == 0 or word == 20 or word == 40 or word == 60 or word == 80 or word == 100 or word == 120:
                return word
            else:
                print("Out of range")
                continue
        except ValueError:
                print("Integer required")

while True:
    while True:
        student_id = input("Enter your student id: ")
        word1 = progression_results("PASS")
        break
    word2 = progression_results("DEFER")
    word3 = progression_results("FAIL")

 # check if total is 120
    total = word1+ word2+ word3
    if total != 120:
        print("Total incorrect")
        continue
    # Get the outcome using credit values.
    if word1 == 120:
        result = "Progress"
        progress +=1
    elif word1 == 100:
        result = "Progress (module trailer)"
        trailer += 1
    else:    
        if word3 == 0 or word3 == 20 or word3 == 40 or word3 == 60:
            result = "Do not Progress - module retriever"
            retriever += 1
        elif word3 == 80 or word3 == 100 or word3 == 120:
            result = "Exclude"
            exclude += 1
    print(result)
    
    student_dic[student_id] = result + " - " + str(word1) + ", " + str(word2) + ", " + str(word3)  # New for part4
    print("would you like to enter another set of data? ")

    # Ask if user wants to enter another set of data or quit
    while True:
        option=input("Enter 'y' for yes or 'q' to quit and view reults: ")
        option=option.lower()   #capital or simple q or y should work 
        if option !="y" and option!="q":
            print("try again.")
            continue
        break  
        
    
    if option=="y":   
        print()
        continue
    elif option=="q":
        break



# Print histogram of outcomes    
print("--------------------------------------")
print("Histogram")

def histogram(progress, trailer, retriever, exclude):

    print("Progress", progress, " :", "*" * progress)
    print("Trailer", trailer, "  :", "*" * trailer)
    print("Retriever", retriever, ":", "*" * retriever)
    print("Excluded", exclude, " :", "*" * exclude)
    total_outcomes = progress + trailer + retriever + exclude
    return total_outcomes


total_outcomes = histogram(progress, trailer, retriever, exclude)
print("Total outcomes:", total_outcomes)


for i in student_dic:                                     # New for part 4
    Input_result += i + " : " + student_dic[i] + " "      # New for part 4
print(Input_result)
