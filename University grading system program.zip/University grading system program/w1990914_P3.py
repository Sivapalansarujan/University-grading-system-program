# I declare that my work contains no examples of misconduct, such as plagiarism, or collusion

# Any code taken from other sources is referenced within my code solution.

# Student ID: w1990914

# Date: 19.04.2023

import os
#Initializing Varibales
progress = 0
trailer  = 0
retriever= 0
exclude  = 0
total=0
students = [] # for part 2

if os.path.exists("progression_data.txt"):
    os.remove("progression_data.txt")

# Loop to input a correct data    
def progression_results(word):
    word_for_describe = word
    while True:
        try:
            word = int(input("Enter your credits at " + word_for_describe + ": "))
            if word == 0 or word == 20 or word == 40 or word == 60 or word == 80 or word == 100 or word == 120:
                return word
            else:
                print("Out of range")
                continue
        except ValueError:
                print("Integer required")

while True:
    word1 = progression_results("PASS")
    word2 = progression_results("DEFER")
    word3 = progression_results("FAIL")
 # check if total is 120
    total = word1+ word2+ word3
    if total != 120:
        print("Total incorrect")
        continue
    # Get the outcome using credit values.
    if word1 == 120:
        result = "Progress"
        progress +=1
    elif word1 == 100:
        result = "Progress (module trailer)"
        trailer += 1
    else:    
        if word3 == 0 or word3 == 20 or word3 == 40 or word3 == 60:
            result = "Do not Progress - module retriever"
            retriever += 1
        elif word3 == 80 or word3 == 100 or word3 == 120:
            result = "Exclude"
            exclude += 1
    print(result)
    students.append(result + " - " + str(word1) + ", " + str(word2) + ", " + str(word3))  # for part 2
    details_file = open("progression_data.txt", "a")
    details_file.write(result + " - " + str(word1) + ", " + str(word2) + ", " + str(word3) + "\n")     
    details_file.close()
    print("would you like to enter another set of data? ")

    # Ask if user wants to enter another set of data or quit
    while True:
        option=input("Enter 'y' for yes or 'q' to quit and view reults: ")
        option=option.lower()   #capital or simple q or y should work 
        if option !="y" and option!="q":
            print("try again.")
            continue
        break  
        
    
    if option=="y":   
        print()
        continue
    elif option=="q":
        break



# Print histogram of outcomes    
print("--------------------------------------")
print("Histogram")

def histogram(progress, trailer, retriever, exclude):

    print("Progress", progress, " :", "*" * progress)
    print("Trailer", trailer, "  :", "*" * trailer)
    print("Retriever", retriever, ":", "*" * retriever)
    print("Excluded", exclude, " :", "*" * exclude)
    total_outcomes = progress + trailer + retriever + exclude
    return total_outcomes


total_outcomes = histogram(progress, trailer, retriever, exclude)
print("Total outcomes:", total_outcomes)
"""for i in students:                                         
    print(i)"""
details_file = open("progression_data.txt", "r")
contents = details_file.read()
print(contents)
details_file.close()
